/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hauntedhouse;


import javax.swing.JOptionPane;

/**
 *
 * @author alyvv
 */
public class HauntedHouseTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        HauntedHouse haunted = new HauntedHouse(); //Object 
        
    String user = JOptionPane.showInputDialog(null, "Enter your name..");
    haunted.setuserName(user); //User will enter their name.
    
    JOptionPane.showMessageDialog(null, "Welcome to my haunted house " 
            + user + "...enjoy.."); //Greeting including User's name.
    
    haunted.Door();
    
        
    }
    
}
