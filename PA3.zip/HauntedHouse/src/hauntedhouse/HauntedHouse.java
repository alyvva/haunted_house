/*
5704522
COP2210 [Fall, 2017]
Assignment 3
11/8/17

I hereby swear and affirm that this work is solely my own, and not the work 
// or the derivative of the work of someone else.

 */
package hauntedhouse;


import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author alyvv
 */
public class HauntedHouse {
    
String userName; 

String getuserName(){
    return userName;
}
void setuserName(String user){
    userName = user;
}

private String choice;
private String choice2;
private String choice3;
private String choice4;
private String choice5;
private String choice6;
private String choice7;
private String choice8;
private String choice9;
private String choice10;
private String choice11;
private String choice12;
private String choice15;

public void Door(){
    
    
   ImageIcon door = new ImageIcon("haunted door.jpg");    
    JOptionPane.showMessageDialog(null, "You are at the front door.", 
            "You are here", 0, door);    
    
    
String choice = JOptionPane.showInputDialog(null, "Where do you want "
                + "to go? 'Living room', 'Dining room' or 'Upstairs'?");
   
if(choice.equals("Living room"))
        {
           LivingRoom();
        }
else if (choice.equals("Dining room"))
        {
           DiningRoom();
        }
else    {
           Upstairs();
        }}


public void LivingRoom() {   
    
    
     ImageIcon livingroom = new ImageIcon("livingroom.jpg");    
    JOptionPane.showMessageDialog(null, "You are now in the living room.", 
            "You are here", 0, livingroom); 
      
    
String choice2 = JOptionPane.showInputDialog(null, "What do you want "
                + "to do next? 'Explore room', 'Enter bathroom', "
                + "Go back to door");  

if (choice2.equals("Explore room"))
        {
           JOptionPane.showMessageDialog(null,"You find a chest. You open it"
                + " and find a ghost! It literally scared you "
                + "to death. Game over."); 
           
           ImageIcon livingroom1 = new ImageIcon("livingroom.jpg");    
           JOptionPane.showMessageDialog(null, "You died in the living room.", 
            "You are here", 0, livingroom1); 
        }
else if (choice2.equals("Enter bathroom"))
        {
           Bathroom();  
        }
else    {
          Door();
        }}

public void DiningRoom() {
    
    
    ImageIcon diningroom = new ImageIcon("diningroom.jpg");    
    JOptionPane.showMessageDialog(null, "You are now in the dining room.", 
            "You are here", 0, diningroom);    
    
    
String choice3 = JOptionPane.showInputDialog(null, "What do you want "
                + "to do next? 'Explore room', 'Enter kitchen',"
                + " 'Go back to door'");
if (choice3.equals("Explore room"))
        {
           JOptionPane.showMessageDialog(null,"The candelebra in the room"
                + " lights up and you see a death shadow... Game over.");
           
           ImageIcon diningroom1 = new ImageIcon("diningroom.jpg");    
           JOptionPane.showMessageDialog(null, "You died in the dining room.", 
            "You are here", 0, diningroom1);
        }
else if (choice3.equals("Enter kitchen"))
        {
           Kitchen();
        }
else    {
           Door();
        }}

public void Bathroom() {
    
    
    ImageIcon bathroom = new ImageIcon("bathroom.jpg");    
    JOptionPane.showMessageDialog(null, "You are now in the bathroom.", 
            "You are here", 0, bathroom);      
    
    
    
String choice4 = JOptionPane.showInputDialog(null, "What do you want "
                + "to do next? 'Check mirror', 'Check shower', "
                + "'Go back to living room'");
if (choice4.equals("Check mirror"))
        {
           JOptionPane.showMessageDialog(null,"You see a bloody face"
                + " looking back at you and die... Game over.");
           
            ImageIcon bathroom0 = new ImageIcon("bathroom.jpg");    
           JOptionPane.showMessageDialog(null, "You died in the bathroom.", 
            "You are here", 0, bathroom0);  
        }
else if (choice4.equals("Check shower"))
        {
           JOptionPane.showMessageDialog(null,"The room suddenly steams up"
                + " and you feel fingers touching the back of your neck"
                + " and die... Game over.");
           
           ImageIcon bathroom0 = new ImageIcon("bathroom.jpg");    
           JOptionPane.showMessageDialog(null, "You died in the bathroom.", 
            "You are here", 0, bathroom0);  
        }
else    {
           LivingRoom();
        }}


public void Kitchen() {
    
    
    ImageIcon kitchen = new ImageIcon("creepykitchen.jpg");    
    JOptionPane.showMessageDialog(null, "You are now in the kitchen.", 
            "You are here", 0, kitchen);
    
    
String choice5 = JOptionPane.showInputDialog(null, "What do you want "
                + "to do next? 'Check fridge', 'Check cabinet', 'Go back to "
                + "dining room', 'Go to pantry'");    
if (choice5.equals("Check fridge"))
        {
           JOptionPane.showMessageDialog(null,"You open the fridge and"
                + " find some delicious soul food. Not a bad outcome. Game over.");
           
           ImageIcon kitchen0 = new ImageIcon("creepykitchen.jpg");    
           JOptionPane.showMessageDialog(null, "You ended the game in the kitchen.", 
            "You are here", 0, kitchen0);
        }
else if (choice5.equals("Check cabinet"))
        {
           JOptionPane.showMessageDialog(null,"The dishes and glasses start "
                + "flying at you as soon as you open the door. You get hit "
                + "in the head and feel yourself start moving towards "
                + "a light... ");
           
            ImageIcon kitchen0 = new ImageIcon("creepykitchen.jpg");    
           JOptionPane.showMessageDialog(null, "You died in the kitchen.", 
            "You are here", 0, kitchen0);
        }
else if (choice5.equals("Go back to dining room"))
        {
           DiningRoom();
        }
else    {
           Pantry();
        }}

public void Pantry() {
    
    ImageIcon pantry = new ImageIcon("pantry.jpg");    
    JOptionPane.showMessageDialog(null, "You are now in the pantry.", 
            "You are here", 0, pantry);
    
    
String choice6 = JOptionPane.showInputDialog(null, "What do you want "
                + "to do next? 'Touch broom', 'Open dusty recipe box',"
                + " 'Go back to kitchen'");  

if (choice6.equals("Touch broom"))
       {
           JOptionPane.showMessageDialog(null,"You touch the broom"
                + " and its owner comes out from the shadows and murders you."
                   + " Game over.");
           
           ImageIcon pantry0 = new ImageIcon("pantry.jpg");    
           JOptionPane.showMessageDialog(null, "You died in the pantry.", 
            "You are here", 0, pantry0);
       }
else if (choice6.equals("Open dusty recipe box"))
       {
           JOptionPane.showMessageDialog(null,"You open the box"
                + " and find a recipe called limb pasta, with the special "
                + "ingredient being human arms... Game over. ");
           
           ImageIcon pantry0 = new ImageIcon("pantry.jpg");    
           JOptionPane.showMessageDialog(null, "You ended the game in the pantry.", 
            "You are here", 0, pantry0);
       }
else   {
           Kitchen();
       }}

public void Upstairs(){
    
    
    ImageIcon stairs = new ImageIcon("stairs.jpg");    
    JOptionPane.showMessageDialog(null, "You are at the stairs.", 
            "You are here", 0, stairs);
    
    
String choice7 = JOptionPane.showInputDialog(null, "What do you want "
                + "to do next? 'Go to bedroom1', 'Go to bedroom2',"
                + " 'Go to Master bedroom'");  

if (choice7.equals("Go to bedroom1"))
       {
          Bedroom1();
           
       }
else if (choice7.equals("Go to bedroom2"))
       {
          Bedroom2();
       }
else   {
          Masterbedroom();
       }}

public void Masterbedroom(){
    
    
   ImageIcon masterbedroom = new ImageIcon("masterbedroom.jpg");    
    JOptionPane.showMessageDialog(null, "You are now in the master bedroom.", 
            "You are here", 0, masterbedroom); 
    
    
String choice8 = JOptionPane.showInputDialog(null, "What do you want "
                + "to do next? 'Explore room', 'Go back to stairs',"
                + " 'Go to Master bathroom'");    
  
if (choice8.equals("Explore room"))
       {
          JOptionPane.showMessageDialog(null,"You open your mother's jewelry box"
                + " and find the cursed Hope Diamond, a diamond stolen from "
                  + "a Hindu statue's eyes and become cursed for life. Another "
                  + "victim it has captured...Game over.");
          
          ImageIcon masterbedroom0 = new ImageIcon("masterbedroom.jpg");    
          JOptionPane.showMessageDialog(null, "You ended the game cursed in the master bedroom.", 
            "You are here", 0, masterbedroom0); 
           
       }
else if (choice8.equals("Go back to stairs"))
       {
          Upstairs();
       }

else   {
          Masterbathroom();
       }
}

public void Masterbathroom() {
    
    
    ImageIcon masterbathroom = new ImageIcon("masterbathroom.jpg");    
    JOptionPane.showMessageDialog(null, "You are now in the master bathroom.", 
            "You are here", 0, masterbathroom);
    
    
String choice9 = JOptionPane.showInputDialog(null, "What do you want "
                + "to do next? 'Check mirror', 'Check shower',"
                + " 'Go back to Master bedroom'");  

if (choice9.equals("Check mirror"))
       {
          JOptionPane.showMessageDialog(null,"You check the mirror"
                  + "and a bloody arm comes from inside the mirror, grabs"
                  + "you and pulls you in...Game over.");
          
           ImageIcon masterbathroom0 = new ImageIcon("masterbathroom.jpg");    
          JOptionPane.showMessageDialog(null, "You died in the master bathroom.", 
            "You are here", 0, masterbathroom0);
    
           
       }
else if (choice9.equals("Check shower"))
       {
          JOptionPane.showMessageDialog(null,"You check the shower"
                  + "and find the key to unlock the house and escape..."
                  + "You manage to make it outside and stay at a hotel for the night."
                  + "You are safe for tonight...");
          
          ImageIcon masterbathroom0 = new ImageIcon("masterbathroom.jpg");    
          JOptionPane.showMessageDialog(null, "You ended the game in the master bathroom"
                  + "by escaping.", 
            "You are here", 0, masterbathroom0);
       }

else   {
          Masterbedroom();
       }  
    
}

public void Bedroom1() {
    
    
    ImageIcon bedroom1 = new ImageIcon("bedroom1.jpg");    
    JOptionPane.showMessageDialog(null, "You are now in the first bedroom.", 
            "You are here", 0, bedroom1);
       
    
String choice10 = JOptionPane.showInputDialog(null, "What do you want "
                + "to do next? 'Check rocking chair', 'Check window',"
                + " 'Go to bathroom2', 'Go back to stairs'");    
  
if (choice10.equals("Check rocking chair"))
        {
           JOptionPane.showMessageDialog(null,"The chair starts rocking by "
                   + "itself with no one on it....Then the door behind you slams"
                   + " shut and it's game over for you...");
           
            ImageIcon bedroom10 = new ImageIcon("bedroom1.jpg");    
          JOptionPane.showMessageDialog(null, "You died in the first bedroom.", 
            "You are here", 0, bedroom10);
        }
else if (choice10.equals("Check window"))
        {
           JOptionPane.showMessageDialog(null,"You see a child outside on the"
                   + " swings looking back at you....suddenly she disappears"
                   + " into the house...Game over.");
           
            ImageIcon bedroom10 = new ImageIcon("bedroom1.jpg");    
          JOptionPane.showMessageDialog(null, "You died in the first bedroom.", 
            "You are here", 0, bedroom10);
        }
else if (choice10.equals("Go to bathroom2"))
        {
           UpstairsBathroom();
        }
else    {
           Upstairs();
        }
}

public void Bedroom2() {
    
    ImageIcon bedroom2 = new ImageIcon("bedroom2.jpg");    
    JOptionPane.showMessageDialog(null, "You are now in the second bedroom.", 
            "You are here", 0, bedroom2);
    
    
String choice11 = JOptionPane.showInputDialog(null, "What do you want "
                + "to do next? 'Check dresser', 'Go back to stairs',"
                + " 'Go to bathroom2', 'Check doll house'");    

if (choice11.equals("Check dresser"))
        {
           JOptionPane.showMessageDialog(null,"A ghost flies up as you open the "
                   + "dresser and flies straight through you, causing you to "
                   + "slip and fall on an item on the floor and you split your "
                   + "head open...Game over.");
           
           ImageIcon bedroom20 = new ImageIcon("bedroom2.jpg");    
           JOptionPane.showMessageDialog(null, "You died in the second bedroom.", 
            "You are here", 0, bedroom20);
    
        }
else if (choice11.equals("Check doll house"))
        {
           JOptionPane.showMessageDialog(null,"The dolls suddenly begin dancing"
                   + " on their own...coming at you slowly. You start to panic"
                   + " and try to run out the room but the door slams shut..."
                   + " Game over. ");
          
           ImageIcon bedroom20 = new ImageIcon("bedroom2.jpg");    
           JOptionPane.showMessageDialog(null, "You died in the second bedroom.", 
            "You are here", 0, bedroom20);
           
        }
else if (choice11.equals("Go to bathroom2"))
        {
           UpstairsBathroom();
        }
else    {
           Upstairs();
        }  
    
}

public void UpstairsBathroom() {
    
    
    ImageIcon upstairsbathroom = new ImageIcon("upstairsbathroom.jpg");    
    JOptionPane.showMessageDialog(null, "You are now in the upstairs bathroom.", 
            "title", 0, upstairsbathroom);  
    
    
String choice12 = JOptionPane.showInputDialog(null, "What do you want "
                + "to do next? 'Check mirror', 'Check shower', 'Go back to bedroom1',"
                + " 'Go back to bedroom2'");  
  
if (choice12.equals("Check mirror"))
        {
           JOptionPane.showMessageDialog(null,"You see yourself in the mirror"
                   + " start decomposing...Game over.");
           
            ImageIcon upstairsbathroom0 = new ImageIcon("upstairsbathroom.jpg");    
           JOptionPane.showMessageDialog(null, "You died in the upstairs bathroom.", 
            "title", 0, upstairsbathroom0);  
        }
else if (choice12.equals("Check shower"))
        {
           JOptionPane.showMessageDialog(null,"As you're checking the shower,"
                   + " the door behind you closes and the room begins steaming"
                   + " up at very dangerous levels..You suffocate. Game over.");
           
            ImageIcon upstairsbathroom0 = new ImageIcon("upstairsbathroom.jpg");    
           JOptionPane.showMessageDialog(null, "You died in the upstairs bathroom.", 
            "title", 0, upstairsbathroom0);  
        }
else if (choice12.equals("Go back to bedroom1"))
        {
           Bedroom1();
        }
else    {
           Bedroom2();
        }  
}



}








